import type { ReactElement } from 'react';
import {
  CakeSlice,
  Cake,
  Utensils,
  Popcorn,
  Salad,
  IceCreamCone,
  Wine,
  Soup,
  UtensilsCrossed,
  Beef,
  Fish,
  CookingPot,
  HandPlatter,
  Carrot,
  Leaf,
  Baby,
  ChefHat,
  Pizza,
  Users,
  BadgePercent,
} from 'lucide-react';
import { LINE_CATEGORY_ICONS, CustomCategoryIcon } from './categoryLineIcons';
import { TodosIcon, LanchesIcon, BebidasIcon } from './MenuIcons';

type IconComponent = (props: { size?: number; className?: string }) => ReactElement;

// Ícone de cada categoria do catálogo fixo (chave = a do backend, em
// `category-catalog.ts`). "todos", "lanches" e "bebidas" usam os SVGs que
// o Felipe mandou; as demais usam ícones de traço do lucide (mesma
// família visual do resto do app), com traço um pouco mais fino pra
// combinar com os desenhos em contorno dos três primeiros.
function line(Icon: typeof Utensils): IconComponent {
  return ({ size = 22, className }) => (
    <Icon size={size} strokeWidth={1.6} className={className} />
  );
}

// Torta: SVG enviado pelo Felipe (28/09), preenchido com `currentColor`
// pra seguir a cor do texto/aba; largura = size e altura proporcional ao
// viewBox original (122.88 x 105.89) pra caber na mesma caixa dos outros.
const TortaIcon: IconComponent = ({ size = 22, className }) => (
  <svg
    width={size}
    height={(105.89 / 122.88) * size}
    viewBox="0 0 122.88 105.89"
    fill="currentColor"
    className={className}
  >
    <path d="M72.13,0.88c0.4-0.51,0.97-0.8,1.57-0.87c0.59-0.07,1.22,0.09,1.72,0.49c0.51,0.4,0.8,0.97,0.87,1.57 c0.07,0.59-0.09,1.22-0.49,1.72c-1.15,1.45-1.51,3.03-1.48,4.67c0.03,1.7,0.49,3.53,0.95,5.36c0.6,2.39,1.2,4.8,1.15,7.27 c-0.05,2.51-0.77,5.04-2.85,7.57l0,0.01c-0.41,0.5-0.98,0.78-1.58,0.84c-0.6,0.06-1.22-0.11-1.72-0.52l-0.01,0 c-0.5-0.41-0.78-0.98-0.84-1.58c-0.06-0.6,0.11-1.22,0.52-1.72c2.66-3.24,1.71-7.02,0.78-10.74C69.54,10.26,68.38,5.61,72.13,0.88 L72.13,0.88z M115.23,87.24l-7.93,17.27c-0.19,0.42-0.5,0.76-0.86,0.99c-0.34,0.22-0.73,0.35-1.14,0.37 c-0.04,0.01-0.08,0.01-0.12,0.01H17.37c-0.51,0-0.99-0.17-1.38-0.45c-0.4-0.29-0.7-0.7-0.85-1.18L8.3,87.24l-0.42-0.02 c-2.32-0.15-4.29-1.24-5.69-2.85C0.81,82.77,0,80.64,0,78.41c0-0.18,0.01-0.38,0.02-0.59c0.08-1.23,0.27-2.35,0.56-3.36 c0.76-2.69,2.21-4.61,4.1-5.82c1.87-1.21,4.16-1.7,6.62-1.55c0.93,0.06,1.88,0.21,2.84,0.45c3.16-7.4,7.19-13.62,11.84-18.66 c5.03-5.47,10.78-9.56,16.89-12.26c2.87-1.27,5.82-2.23,8.81-2.89c3.01-0.66,6.08-1.01,9.17-1.05c3.07-0.04,6.15,0.23,9.2,0.8 c3.03,0.57,6.03,1.45,8.96,2.64c6.45,2.6,12.59,6.68,18.04,12.22c5.03,5.11,9.47,11.47,13.02,19.08c2.05-0.58,4.18-0.76,6.14-0.25 c1.84,0.47,3.51,1.55,4.79,3.44c1.62,2.38,2.2,5.72,1.75,8.83c-0.43,2.99-1.81,5.79-4.13,7.39c-0.2,0.14-0.41,0.24-0.63,0.31 c-0.19,0.06-0.38,0.09-0.58,0.1c-0.04,0.01-0.08,0.01-0.12,0.01H115.23L115.23,87.24z M105.39,69.14 c-3.29-6.95-7.36-12.75-11.94-17.39c-4.95-5.02-10.49-8.7-16.3-11.04c-2.63-1.06-5.32-1.85-8.03-2.37 c-2.73-0.52-5.49-0.76-8.22-0.72c-2.73,0.04-5.46,0.35-8.16,0.95c-2.68,0.59-5.32,1.45-7.88,2.59 c-5.44,2.41-10.57,6.04-15.09,10.91c-4.18,4.5-7.84,10.05-10.75,16.66L19.5,69l0.98,0.57c1.58,0.94,3.17,1.87,4.72,2.12 c1.49,0.24,3.03-0.16,4.66-1.81c1.03-1.04,2.06-1.89,3.17-2.49c1.14-0.61,2.36-0.96,3.73-0.99c1.27-0.02,2.62,0.25,4.09,0.89 c1.43,0.62,3,1.57,4.75,2.93c0.5,0.39,1.11,0.7,1.77,0.92c0.69,0.23,1.44,0.37,2.19,0.4c0.7,0.03,1.38-0.04,1.99-0.2 c0.55-0.15,1.05-0.37,1.45-0.69c0.71-0.56,1.43-1.1,2.16-1.59c0.74-0.5,1.5-0.96,2.29-1.35c0.85-0.42,1.73-0.76,2.63-0.98 c0.91-0.22,1.84-0.33,2.81-0.28c4.15,0.2,5.81,2.08,7.39,3.92c0.03,0.03,0.06,0.06,0.09,0.1c0.86,1,1.71,1.96,3.44,1.96 c2.44,0.01,3.95-1.4,5.38-2.72l0.01-0.01c1.7-1.57,3.32-3.07,5.7-3.49c2.35-0.41,5.36,0.26,9.75,3.05 c2.92,1.85,5.02,2.26,6.69,1.98C102.94,70.97,104.2,70.04,105.39,69.14L105.39,69.14z M49.69,0.96c0.38-0.52,0.94-0.84,1.53-0.93 l0.06-0.01c0.57-0.07,1.18,0.06,1.68,0.43c0.52,0.38,0.84,0.94,0.93,1.53l0.01,0.06c0.07,0.57-0.06,1.18-0.43,1.68 c-2.56,3.5-1.72,7.19-0.88,10.86l0.01,0.05c0.5,2.21,1,4.41,0.97,6.69c-0.03,2.34-0.6,4.72-2.26,7.18 c-0.36,0.54-0.91,0.88-1.5,0.99c-0.59,0.11-1.22,0-1.75-0.36c-0.54-0.36-0.88-0.91-0.99-1.5c-0.11-0.59,0-1.22,0.36-1.75 c1.09-1.62,1.45-3.27,1.43-4.95c-0.02-1.72-0.42-3.51-0.83-5.3l-0.01-0.05C46.94,10.89,45.88,6.17,49.69,0.96L49.69,0.96z M48.85,45.21c0.44-0.47,1.03-0.72,1.63-0.74c0.6-0.02,1.21,0.19,1.68,0.62c0.47,0.44,0.72,1.03,0.74,1.63 c0.02,0.6-0.19,1.21-0.62,1.68l-6.4,6.88c-0.44,0.47-1.03,0.72-1.63,0.74c-0.6,0.02-1.21-0.18-1.68-0.62 c-0.47-0.44-0.72-1.03-0.74-1.63c-0.02-0.6,0.18-1.21,0.62-1.68L48.85,45.21L48.85,45.21z M72.04,48.4 c-0.44-0.47-0.65-1.08-0.62-1.68c0.02-0.6,0.27-1.19,0.74-1.63c0.47-0.44,1.08-0.65,1.68-0.62c0.6,0.02,1.19,0.27,1.63,0.74 l6.4,6.88c0.44,0.47,0.65,1.08,0.62,1.68c-0.02,0.6-0.27,1.19-0.74,1.63c-0.47,0.44-1.08,0.65-1.68,0.62 c-0.6-0.02-1.19-0.27-1.63-0.74L72.04,48.4L72.04,48.4z M59.6,48.39l0-0.07c0.02-0.62,0.28-1.18,0.7-1.58 c0.42-0.42,1.01-0.67,1.65-0.67l0.07,0c0.62,0.02,1.18,0.28,1.58,0.69c0.42,0.43,0.68,1.01,0.67,1.65l-0.08,8.15 c-0.02,0.62-0.29,1.18-0.7,1.58c-0.42,0.42-1.01,0.67-1.65,0.67l-0.07,0c-0.62-0.02-1.18-0.28-1.58-0.69 c-0.42-0.43-0.68-1.01-0.67-1.65L59.6,48.39L59.6,48.39z M108.26,73.18c-1.8,1.37-3.72,2.75-6.3,3.15 c-2.58,0.4-5.75-0.21-9.96-2.88c-5.65-3.59-7.45-1.95-9.41-0.13l-0.05,0.04c-1.03,0.96-2.1,1.95-3.46,2.71 c-1.39,0.78-3.07,1.31-5.26,1.3c-2.01,0-3.43-0.47-4.55-1.18c-1.11-0.71-1.89-1.61-2.68-2.52l-0.06-0.08 c-0.46-0.53-0.92-1.06-1.5-1.45c-0.59-0.4-1.33-0.69-2.36-0.74c-0.49-0.02-0.98,0.04-1.47,0.16c-0.51,0.13-1.02,0.34-1.54,0.59 c-0.59,0.29-1.17,0.65-1.76,1.05c-0.6,0.41-1.21,0.87-1.82,1.35c-0.89,0.7-1.92,1.2-3.04,1.51c-1.16,0.33-2.41,0.47-3.66,0.42 c-1.24-0.05-2.5-0.28-3.67-0.69c-1.14-0.39-2.22-0.95-3.13-1.66c-1.31-1.01-2.42-1.73-3.39-2.18c-0.92-0.43-1.68-0.62-2.35-0.61 c-0.56,0.01-1.1,0.19-1.65,0.52c-0.59,0.35-1.18,0.86-1.8,1.49c-1.05,1.06-2.07,1.85-3.06,2.42c-1,0.57-1.97,0.9-2.92,1.06 c-1.89,0.4-3.68,0.11-5.41-0.53c-1.68-0.62-3.29-1.57-4.9-2.51c-2.03-1.19-4.17-1.95-6.11-2.07c-1.12-0.07-2.17,0.07-3.07,0.48 c-0.88,0.4-1.63,1.05-2.19,1.99c-0.57,0.97-0.94,2.26-1.05,3.92c-0.08,1.29,0.23,2.33,0.86,3.07c0.64,0.75,1.62,1.22,2.89,1.37 h107.99c1-1.04,1.58-2.65,1.74-4.34c0.17-1.83-0.17-3.71-1.05-5c-0.81-1.19-2-1.66-3.3-1.69 C111.99,71.49,109.92,72.27,108.26,73.18L108.26,73.18z M60.94,0.97c0.38-0.52,0.93-0.84,1.53-0.94c0.59-0.09,1.22,0.04,1.74,0.41 c0.52,0.38,0.84,0.93,0.94,1.53c0.09,0.59-0.04,1.22-0.41,1.74c-1.3,1.79-1.72,3.57-1.71,5.35c0.01,1.82,0.48,3.68,0.94,5.52 c0.57,2.26,1.13,4.5,1.09,6.81c-0.04,2.36-0.69,4.75-2.57,7.22c-0.39,0.51-0.95,0.82-1.55,0.9c-0.59,0.08-1.22-0.07-1.73-0.46 c-0.51-0.39-0.82-0.95-0.9-1.55c-0.08-0.59,0.07-1.22,0.46-1.73c1.19-1.56,1.58-3.17,1.56-4.81c-0.02-1.69-0.46-3.46-0.91-5.25 c-0.58-2.29-1.16-4.61-1.12-7.05C58.32,6.19,58.99,3.64,60.94,0.97L60.94,0.97z M109.95,87.54H13.46l5.49,13.65h84.74L109.95,87.54 L109.95,87.54z" />
  </svg>
);

// Ícone da seção "Promoções" do cardápio — mesma família de traço (lucide,
// traço fino 1.6) dos ícones das categorias da aba "Todos".
export const PromocoesIcon: IconComponent = line(BadgePercent);

export const CATEGORY_ICONS: Record<string, IconComponent> = {
  todos: TodosIcon,
  lanches: LanchesIcon,
  bebidas: BebidasIcon,
  sobremesas: line(CakeSlice),
  entradas: line(Utensils),
  petiscos: line(Popcorn),
  saladas: line(Salad),
  sorvetes: line(IceCreamCone),
  bolos: line(Cake),
  tortas: TortaIcon,
  vinhos: line(Wine),
  'sopas-caldos': line(Soup),
  'pratos-principais': line(UtensilsCrossed),
  'carnes-grelhados': line(Beef),
  'peixes-frutos-do-mar': line(Fish),
  'massas-risotos': line(CookingPot),
  'pratos-executivos': line(HandPlatter),
  acompanhamentos: line(Carrot),
  'menu-vegetariano': line(Leaf),
  'menu-infantil': line(Baby),
  'menu-degustacao': line(ChefHat),
  combinados: line(Pizza),
  'pratos-compartilhar': line(Users),
  // Categorias novas (02/10) e o ajuste do "combinados" — ver categoryLineIcons.tsx.
  ...LINE_CATEGORY_ICONS,
};

// Nomes do catálogo → chave, só pra achar o ícone de categorias LEGADAS
// (criadas à mão antes do catálogo, `key` nulo). Sem casamento, sem ícone.
const NAME_TO_KEY: Record<string, string> = {
  todos: 'todos',
  lanches: 'lanches',
  bebidas: 'bebidas',
  sobremesas: 'sobremesas',
  entradas: 'entradas',
  saladas: 'saladas',
  sorvetes: 'sorvetes',
  vinhos: 'vinhos',
};

function normalize(label: string): string {
  return label
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

export function getCategoryIcon(
  key: string | null | undefined,
  name: string,
): IconComponent | undefined {
  if (key && CATEGORY_ICONS[key]) return CATEGORY_ICONS[key];
  const byName = NAME_TO_KEY[normalize(name)];
  if (byName) return CATEGORY_ICONS[byName];
  // Categoria PERSONALIZADA (criada pelo dono, sem chave do catálogo):
  // ícone genérico de etiqueta, no mesmo traço fino das demais.
  return key ? undefined : CustomCategoryIcon;
}
