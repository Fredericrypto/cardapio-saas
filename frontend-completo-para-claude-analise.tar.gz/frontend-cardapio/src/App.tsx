import { LanguagePage } from './pages/LanguagePage';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { CartProvider } from './contexts/CartContext';
import { MenuPage } from './pages/MenuPage';
import { LocationPickerPage } from './pages/LocationPickerPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { PromotionDetailPage } from './pages/PromotionDetailPage';
import { CartPage } from './pages/CartPage';
import { MyAccountPage } from './pages/MyAccountPage';
import { CustomerAuthPage } from './pages/CustomerAuthPage';
import { CustomerProfilePage } from './pages/CustomerProfilePage';
import { OrdersHubPage } from './pages/OrdersHubPage';
import { OrderHistoryPage } from './pages/OrderHistoryPage';
import { OrderReceiptMesaPage } from './pages/OrderReceiptMesaPage';
import { OrderReceiptAvulsoPage } from './pages/OrderReceiptAvulsoPage';
import { EditProfilePage } from './pages/EditProfilePage';
import { SavedAddressPage } from './pages/SavedAddressPage';
import { CustomerPixWalletPage } from './pages/CustomerPixWalletPage';
import { CustomerCashbackPage } from './pages/CustomerCashbackPage';
import { MyReviewsPage } from './pages/MyReviewsPage';
import { PublicReviewsPage } from './pages/PublicReviewsPage';
import { ItemReviewsPage } from './pages/ItemReviewsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { RequireCustomerAuth } from './components/RequireCustomerAuth';
import { OptionalCustomerAuth } from './components/OptionalCustomerAuth';
import { CustomerAppShell } from './components/CustomerAppShell';
import { TableSessionGate } from './components/TableSessionGate';

function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/:slug" element={<CustomerAppShell />}>
            {/* Fluxo de mesa (QR code físico na mesa) — mesmo MenuPage do
                fluxo geral, só com qrCodeToken presente na URL.
                DECISÃO DE PRODUTO (revista): NÃO exige mais login — o
                cliente já está fisicamente no restaurante ao escanear a
                mesa, pedir conta antes disso só afasta quem quer só um
                lanche rápido. Ver OptionalCustomerAuth pro raciocínio
                completo. Login continua liberando cashback/avaliação/
                histórico pra quem quiser, só deixou de ser obrigatório
                pra pedir. TableSessionGate continua resolvendo "existe
                sessão ativa nessa mesa?" independente de login. */}
            <Route
              path="mesa/:qrCodeToken"
              element={
                <OptionalCustomerAuth>
                  <TableSessionGate>
                    <MenuPage />
                  </TableSessionGate>
                </OptionalCustomerAuth>
              }
            />
            <Route
              path="mesa/:qrCodeToken/conta"
              element={
                <OptionalCustomerAuth>
                  <TableSessionGate>
                    <MyAccountPage />
                  </TableSessionGate>
                </OptionalCustomerAuth>
              }
            />
            <Route
              path="mesa/:qrCodeToken/produto/:productId"
              element={
                <OptionalCustomerAuth>
                  <TableSessionGate>
                    <ProductDetailPage />
                  </TableSessionGate>
                </OptionalCustomerAuth>
              }
            />
            <Route
              path="mesa/:qrCodeToken/promocao/:promotionId"
              element={
                <OptionalCustomerAuth>
                  <TableSessionGate>
                    <PromotionDetailPage />
                  </TableSessionGate>
                </OptionalCustomerAuth>
              }
            />
            <Route
              path="mesa/:qrCodeToken/carrinho"
              element={
                <OptionalCustomerAuth>
                  <TableSessionGate>
                    <CartPage />
                  </TableSessionGate>
                </OptionalCustomerAuth>
              }
            />

            {/* Fluxo geral (sem mesa: retirada/entrega) */}
            <Route
              index
              element={
                <RequireCustomerAuth>
                  <MenuPage />
                </RequireCustomerAuth>
              }
            />
            <Route path="avaliacoes" element={<PublicReviewsPage />} />
            {/* Avaliações de um item — pública como a do restaurante; serve os
                dois fluxos (geral e mesa), o voltar usa o histórico. */}
            <Route path="produto/:productId/avaliacoes" element={<ItemReviewsPage />} />
            <Route
              path="escolher-loja"
              element={
                <RequireCustomerAuth>
                  <LocationPickerPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="produto/:productId"
              element={
                <RequireCustomerAuth>
                  <ProductDetailPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="promocao/:promotionId"
              element={
                <RequireCustomerAuth>
                  <PromotionDetailPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="carrinho"
              element={
                <RequireCustomerAuth>
                  <CartPage />
                </RequireCustomerAuth>
              }
            />

            {/* Conta do cliente final — SEMPRE dentro do restaurante
                (:slug). Cliente é por restaurante, não uma conta cruzando
                vários. A tela de entrar/criar conta é a ÚNICA rota que
                nunca exige login (senão ninguém conseguiria logar). */}
            <Route path="conta-cliente/entrar" element={<CustomerAuthPage />} />
            <Route
              path="conta-cliente/perfil"
              element={
                <RequireCustomerAuth>
                  <CustomerProfilePage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/pedidos"
              element={
                <RequireCustomerAuth>
                  <OrdersHubPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/pedidos/historico"
              element={
                <RequireCustomerAuth>
                  <OrderHistoryPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/pedidos/mesa/:sessionId"
              element={
                <RequireCustomerAuth>
                  <OrderReceiptMesaPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/pedidos/avulso/:orderId"
              element={
                <RequireCustomerAuth>
                  <OrderReceiptAvulsoPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/dados"
              element={
                <RequireCustomerAuth>
                  <EditProfilePage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/endereco"
              element={
                <RequireCustomerAuth>
                  <SavedAddressPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/carteira-pix"
              element={
                <RequireCustomerAuth>
                  <CustomerPixWalletPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/cashback"
              element={
                <RequireCustomerAuth>
                  <CustomerCashbackPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/avaliacoes"
              element={
                <RequireCustomerAuth>
                  <MyReviewsPage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/idioma"
              element={
                <RequireCustomerAuth>
                  <LanguagePage />
                </RequireCustomerAuth>
              }
            />
            <Route
              path="conta-cliente/notificacoes"
              element={
                <RequireCustomerAuth>
                  <NotificationsPage />
                </RequireCustomerAuth>
              }
            />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </CartProvider>
  );
}

export default App;
