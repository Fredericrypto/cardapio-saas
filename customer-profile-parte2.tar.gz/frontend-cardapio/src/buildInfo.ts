// Ver /home/claude/work/frontend-admin/src/buildInfo.ts — mesma ideia,
// pro app do cliente. Atualizo essa string manualmente a cada entrega.
export const BUILD_VERSION = '2026-10-12-sessao-z6-12';
